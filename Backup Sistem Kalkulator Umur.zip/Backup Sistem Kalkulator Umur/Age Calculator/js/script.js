function expand(lbl){

    var up = lbl.getAttribute("for");

    document.getElementById(up).style.height = "45px";

    document.getElementById(up).classList.add("my-style");
    
    lbl.style.transform = "translateY(-45px)";
}
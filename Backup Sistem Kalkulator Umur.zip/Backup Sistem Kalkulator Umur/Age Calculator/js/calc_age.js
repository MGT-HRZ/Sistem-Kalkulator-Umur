// putting name

    var nme = document.getElementById("name");

    let showName = document.getElementById("show-name");

// calculate age

    let dy = document.getElementById("day");
    let mnth = document.getElementById("month");
    let yr = document.getElementById("year");

    let showDay = document.getElementById("show-day");
    let showMonth = document.getElementById("show-month");
    let showYear = document.getElementById("show-year");

    const btn = document.getElementById("calc-btn");

    // current date

    var today = new Date();
    let d = today.getDate();
    var m = today.getMonth() + 1;
    var y = today.getFullYear();
    let maxDays = 0;
    let monthNum = 1;

    // entered date / input

    btn.addEventListener("click", (name, days, month, year) => {

        name = nme.value;
        days = dy.value;
        month = mnth.value;
        year = yr.value;

        if (nme.value == "" || dy.value == "" || mnth.value == "" || yr.value == "") {
            return alert("Please enter your name and date of birth properly to calculate your age")
    }

    // no else condition needed

    console.log(`Current Date : ${d} ${m} ${y}`);

    if (m == 1) { // January
        maxDays = 31;
        monthNum = 1;
    }

    else if (m == 2) { // February
        maxDays = 28;
        monthNum = 2;
    }

    else if (m == 3) { // March
        maxDays = 31;
        monthNum = 3;
    }

    else if (m == 4) { // April
        maxDays = 30;
        monthNum = 4;
    }

    else if (m == 5) { // May
        maxDays = 31;
        monthNum = 5;
    }

    else if (m == 6) { // June
        maxDays = 30;
        monthNum = 6;
    }

    else if (m == 7) { // July
        maxDays = 31;
        monthNum = 7;
    }
    else if (m == 8) { // August
        maxDays = 31;
        monthNum = 8;
    }

    else if (m == 9) { // September
        maxDays = 30;
        monthNum = 9;
    }

    else if (m == 10) { // October
        maxDays = 31;
        monthNum = 10;
    }

    else if (m == 11) { // November
        maxDays = 30;
        monthNum = 11;
    }

    else if (m ==12) { // December
        maxDays = 31;
        monthNum = 12;
    }

    var ageYears = y - year;

    if (m <= month) {
        m = m + 12;
    }

    var ageMonths = m - month;

    var ageDays = (maxDays - d) + parseInt(days);

    // console.log(`Your age :  ${ageYears} years, ${ageMonths} months and ${ageDays} days`);

    showName.innerHTML = name;

    showDay.innerHTML = ageDays;

    showMonth.innerHTML = ageMonths;

    showYear.innerHTML = ageYears;

})  /* }) <=== btn.addEventListener */